const Button = () => {
  return (
    <>
      <button
        type="submit"
        className="btn btn-outline btn-default my-5 text-black"
      >
        Submit
      </button>
    </>
  );
};

export default Button;
