import FormAddCuisine from "../components/formAddCui";

const AddCuisine = () => {
  return (
    <>
      <section className="bg-slate-800">
        <FormAddCuisine />
      </section>
    </>
  );
};

export default AddCuisine;
