import UploadForm from "../components/uploadForm";

const UploadImg = () => {
  return (
    <>
      <UploadForm />
    </>
  );
};

export default UploadImg;
