import FormUpdate from "../components/form";

const UpdateCuisine = () => {
  return (
    <>
      <FormUpdate />
    </>
  );
};

export default UpdateCuisine;
